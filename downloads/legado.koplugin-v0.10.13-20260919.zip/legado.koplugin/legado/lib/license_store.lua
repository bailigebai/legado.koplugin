local Json = require("legado.lib.json_codec")

local Store = {}
Store.__index = Store

function Store.new(settings)
    return setmetatable({ settings = settings }, Store)
end

function Store:readSetting(key)
    if not self.settings or type(self.settings.get) ~= "function" then return nil end
    local value = self.settings:get(key)
    if key == "license_receipt" and type(value) == "string" and value ~= "" then
        local ok, decoded = pcall(Json.decode, value)
        return ok and decoded or nil
    end
    return value ~= "" and value or nil
end

function Store:saveSetting(key, value)
    if not self.settings or type(self.settings.set) ~= "function" then return false end
    if key == "license_receipt" then
        local ok, encoded = pcall(Json.encode, value)
        if not ok then return false end
        return self.settings:set(key, encoded) ~= nil
    end
    return self.settings:set(key, value) ~= nil
end

-- Disk rollback can fail too. Restore the cached value independently so an
-- unconfirmed activation is never usable in the current reading session.
function Store:restoreSetting(key, value)
    if key == "license_receipt" and value ~= nil then value = Json.encode(value) end
    self.settings.values[key] = value or ""
end

function Store:flush()
    -- Settings:set already writes atomically; confirm through its disk reader,
    -- not the cached values, before License accepts the activation.
    local adapter = self.settings and self.settings.adapter
    if not adapter or type(adapter.read) ~= "function" then return false end
    local ok, saved = pcall(adapter.read)
    if not ok or type(saved) ~= "table" then return false end
    for _, key in ipairs({ "license_receipt", "license_installation_id" }) do
        if saved[key] ~= self.settings:get(key) then return false end
    end
    return true
end

return Store
