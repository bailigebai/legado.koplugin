# KOReader 书源阅读插件

`legado.koplugin` 在 Kindle KOReader 上独立运行。v0.10.13 的短密钥仅解锁阅读小票展示和阅读回顾数据展示；书架数量不限，其他功能免费。首次激活联网绑定设备，之后可离线验证；沿用已发放的 Legado 短密钥。新安装不内置书源，需要从本地 JSON 或网址自行导入。无感阅读默认使用参考 Swipe_Animation 的擦除渐显动画，并兼容缺少 Fast 刷新接口的 Kindle。阅读顶栏新增“无感阅读：启用”，使用基于 Leko 的独立文字阅读器；独立阅读菜单点击“关闭无感阅读”可回到 KOReader。双向切换保留章节和近似章内位置，两种排版分别按书保存。阅读页目录新增侧边懒加载面板，每页 24 章，可放在左侧或右侧。详见 [本期功能与验收](docs/reader-library-0.10.0.md)。

目标设备是 Kindle Paperwhite 第 6 代（KPW6）、Kindle 固件 5.19.5。自动兼容基线为 KOReader v2026.07.1，并尽量只使用长期存在的 Lua/LuaJIT、UI、网络和文件接口。2026-09-14 已通过 MTP 读取 KPW6 的实际代码和日志，并安装小票重画修复；物理触屏及安装包清单中的设备项目仍待验收。

2026-09-15 稳定性修复：无感阅读的设置、菜单关闭和控件显示统一收口，控件异常不会退出 KOReader；新增缓存容量统计、默认 500 MiB 上限、超过 300 MiB 时按最旧文件清理到 200 MiB，当前阅读书籍受保护。详见 [测试说明](docs/testing.md)。

2026-09-16 v0.10.8：完整下一章预读、跨章首屏准备、异步联网激活和资源生命周期修复，见 [本版改动与验收](docs/reader-library-0.10.8.md)。该版本的宿主验证已经完成，Kindle 实机验收未完成。

2026-09-16 v0.10.11：移除内置书源合集、固定合集链接、自动初始化及恢复默认入口；手动导入、搜索发现、阅读、预读、小票授权与用户数据保留。见 [本版安装与验收](docs/reader-library-0.10.11.md)。
2026-09-18 v0.10.12：保留无感阅读切换的真实错误原因；已预加载且版式匹配的下一章跳过重复离屏校验，减少 Kindle 翻章阻塞。无感阅读切换失败时保留当前阅读页面。
2026-09-18 v0.10.13：新增参考 SideTOC 的阅读页侧边目录。网络书籍按 24 章一页懒加载，侧栏打开时不阻塞当前正文；本地文档读取 KOReader 原生目录。支持左/右侧位置设置、当前章高亮、选择章节、取消请求和关闭清理。

2026-09-16 v0.10.10：后三章完整正文滚动预取，缺少目录立即补齐；无感阅读提前分页并复用窗口，新安装默认使用普通翻页过渡。保留已有动画设置。详见 [跨章优化与验收](docs/reader-library-0.10.10.md)。

2026-09-16 v0.10.9：授权改用已直连实测的本产品 Pages 入口，补齐授权磁盘读回确认及异设备绑定错误提示。真实激活、验签、离线重启与库存保持检查通过；Kindle Wi-Fi 仍待实机验收。见 [本版改动与验收](docs/reader-library-0.10.9.md)。

## 安装

1. 安装并确认 KOReader 能在 Kindle 上正常启动。
2. 解压 `legado.koplugin-v0.10.13-20260918.zip`；压缩包只有一个顶层目录 `legado.koplugin/`。升级前退出 KOReader，保留数据目录，只替换旧插件代码目录。
3. 将该目录完整复制到 KOReader 的 `koreader/plugins/` 下，最终应存在 `koreader/plugins/legado.koplugin/main.lua`。
4. 完全退出并重新启动 KOReader，点屏幕顶部打开菜单，进入“工具 → 书源阅读”。文件浏览界面和书籍阅读界面均可打开书架、搜索、发现或书源管理。

插件不内置书源，也不自动下载或恢复书源。首次使用请进入“更多 → 书源管理”，选择“从本地 JSON 导入”或“从网址导入”，填入自己的文件路径或合集地址。导入后可正常聚合搜索、浏览发现分类和阅读。没有书源时，发现提示“请先导入书源”。升级保留设备上已经保存的书源、书架、进度、设置和授权；旧书源统一在管理页显示，可自行停用或删除。开发回归使用的书源样本不随安装包分发。

## 功能与边界

- 导入单个或数组形式的 Legado JSON 书源，扫描搜索、详情、目录和正文规则兼容性。
- 输入书名直接搜索全部启用书源，无需先选网站；搜索结果逐步显示，同名同作者合并，卡片包含封面、简介和已匹配的来源数量。可停止、翻页、查看失败详情、选择匹配来源；书架内也可重新查找来源。
- 发现按“站点 → 分类 → 图书卡片 → 详情”浏览，分类分页保留返回路径；不支持的规则显示具体状态，没有发现规则的书源仍可搜索。
- 保存书架、章节目录、阅读位置、缓存和下载任务；SQLite 不可用时降级为原子 Lua 索引文件。
- 默认首页展示全部收藏，每页 4 列×3 行，只显示封面和书名；顶部切换全部、在读、未读及自定义分类。书源、下载、设置等收进“更多”。点书后查看大封面与完整简介。
- 逐章阅读，首次只取前三章目录信息并优先打开第一章；预读与完整目录在进入正文后处理。断网可读已有缓存；整本 EPUB 下载支持取消、重试和重启恢复。
- 阅读和简介“更多”中均可切换站点书源。只列同书名同作者，章节最多在前，未知章节数在后；搜索和目录计数每 6 秒合并刷新。
- 字体与背景由 KOReader 控制，本插件不向正文写入固定字体、颜色或背景；网络书的原生排版设置按书保存，切章、目录跳转、重开和明确换源时恢复，不共享章节进度或批注。
- 页眉页脚使用小字，与阅读正文一起绘制；时间按分钟局部刷新，关闭阅读器时取消刷新。在线小说进度是按章节估算，完整目录未知时显示“目录加载中”；本地书取 KOReader 文档进度。
- 阅读回顾数据和阅读小票展示需要短密钥，书架、搜索、导入、下载、原生/无感阅读及 KOReader 原生统计免费。未激活也正常保存阅读进度与时长，激活后可查看既有记录。
- 阅读回顾包含累计时长、月/周柱状图、每日月历、已读书籍封面分页。点书切换为阅读小票，可保存“在读 / 搁置 / 读完”和星级；返回保留原月份和页码。保留旧累计时长，从本版开始按日记录，不补造过去的每日数据。
- 阅读小票默认宽度为屏幕的 75%，提供阅读票据、封面进度卡、日历胶片及书店结账单、阅读登机牌、图书馆借阅卡、影院票根、阅读明信片、阅读日报九种样式。点击整个屏幕顶部四分之一区域显示返回、尺寸和样式按钮，点击底部短评可编辑；有短评后只显示内容。阅读回顾的小票默认白色背景，可在“阅读书籍”页底部设置背景图片；顶栏“当前书籍小票”直接悬浮于正文。
- 本版移除听书入口。搜索、封面、简介、书架与分类页面由插件管理，正文调用 KOReader 阅读器。

本插件优先支持常用 `class/tag/id/children` 链式规则及 CSS、JSONPath、XPath、模板子集。`##` 清理采用 Lua 模式匹配，不是完整 Java 正则表达式。它仅解析明确列出的受限表达式，不执行任意 JavaScript，不提供 WebView、登录界面、Java/Android API。依赖这些能力的核心步骤仍不能执行；仅封面、简介等辅助字段不兼容时，会保留可识别的书籍；本版本不等同于完整移植 Legado_Max。详细规则见 [规则兼容表](docs/rule-compatibility.md)。

## 本版参考与改进

布局与流程参考 Legado_Max 的 SearchModel、item_search.xml、ExploreAdapter 和 BookInfoActivity。使用 KOReader 原生控件实现插件全屏页面，复用插件自己的 SQLite 图书元信息和封面缓存，不调用 FileManager 的书本管理或封面系统。详情返回列表时复用已加载的元信息。

网络实测修复了未解压 gzip 网页造成的解析失败。现在调用 KOReader 自带 zlib，解压前限定输出大小；封面字节不经过文本编码转换。保留此前针对 SQLite 书源分号、919源持久化及菜单入口的修复。

[0.3.1 操作与验证记录](docs/compact-shelf-reader-0.3.1.md) 记录本版书架及阅读文件修复。之前的真实站点抽测见 [0.3.0 记录](docs/library-browser-0.3.0.md)，数据库故障证据保留在 [导入修复记录](docs/acceptance-2026-09-10.md)。

## 故障排查

- 插件管理器里也没有“书源阅读”：确认最终路径为 `koreader/plugins/legado.koplugin/main.lua`，没有多套一层目录；保留此次启动后的 `koreader/crash.log`，核对实际安装包和加载错误。
- 插件管理器已勾选，但工具菜单没有入口：当前版本不在菜单注册时启动服务；完全退出再启动，进入顶部菜单“工具 → 书源阅读”。若仍缺失，请保留本次启动日志；若点击后出现失败提示，同时保留提示中的版本和代码位置。
- 导入显示 `STORAGE_ERROR`：确认已更新至 v0.3.1。新版按实际故障显示“保存本地数据库”、空间不足、只读或占用等原因，不再把保存失败解释为书源规则错误。请保留原数据库，不要通过删除数据来重试。
- 开始阅读显示 `STORAGE_ERROR`：v0.3.1 修正了阅读文件被错误写成缓存 JSON 包装，以及首次下载时提前返回缓存不存在错误的问题。更新后重新打开该书会重新生成阅读文档；若仍失败，详情的“更多 → 阅读诊断”会显示缓存写入或打开阅读器等具体阶段。
- 发现提示“请先导入书源”：当前没有已导入书源，请进入书源管理导入自己的 JSON 文件或网址。新版不再提供“恢复默认书源”。
- 书源显示 `partial` 或 `unsupported`：打开“书源管理 → 兼容性报告”，检查 capability 和 issue；超出受限表达式范围的 JavaScript、WebView、登录或 Android API 规则不能执行。
- 搜索、目录或正文失败：先运行四步诊断，依据安全的 HTTP 状态、字符集和错误代码检查网址、规则与网络。诊断不会显示请求/响应正文或凭据。
- GBK/GB18030 页面报编码错误：当前 KOReader 构建需要提供 iconv；插件不会用错误编码继续写缓存。
- 设置页提示“设置文件损坏”：普通保存会保持锁定以保护原文件。可先选择“重试读取”；确认文件无法修复后，选择“备份后重置”并输入“重置”。插件会将原始字节保存为未占用的 `legado.json.corrupt-*`，再原子写入安全默认设置；请保留备份直到确认新设置可用。
- 重启后数据异常：先退出 KOReader，备份下述数据目录，再检查存储空间和 `legado.sqlite`；不要在 KOReader 运行时手工修改文件。

## 卸载与清理

运行数据根目录是 `${DataStorage:getDataDir()}/legado`，即 KOReader `DataStorage:getDataDir()` 返回目录下的 `legado/`。各路径与代码中的实际用途如下：

- `${DataStorage:getDataDir()}/settings/legado.json`：插件设置（请求限制、并发数、预取数量、书架显示等）；它使用版本化 JSON 和原子替换，不在 `legado/` 数据根目录内。旧版 `legado.lua` 只会按受限数据格式读取（不会执行 Lua），成功写入 JSON 后完成迁移。损坏恢复产生的 `legado.json.corrupt-*` 是原始字节备份。
- `${DataStorage:getDataDir()}/legado/legado.sqlite`：书源、书架、目录、阅读进度和下载任务；SQLite 不可用时同一路径保存 Lua 降级索引。
- `${DataStorage:getDataDir()}/legado/cache/`：目录与章节正文缓存。
- `${DataStorage:getDataDir()}/legado/covers/`：搜索/书架封面缓存。
- `${DataStorage:getDataDir()}/legado/downloads/`：整本 EPUB、构建中的 `.part` 文件和更新版本。

普通卸载时先完全退出 KOReader，再删除 `koreader/plugins/legado.koplugin/`；这不会自动删除个人数据或设置。若要完整清理，先备份需要保留的 EPUB，然后同时删除 `${DataStorage:getDataDir()}/legado/`、`${DataStorage:getDataDir()}/settings/legado.json`、对应的 `legado.json.corrupt-*` 备份，以及仍存在的旧版 `${DataStorage:getDataDir()}/settings/legado.lua`。只删除 `legado/` 不会清除设置。只想释放空间时，可在 KOReader 退出后单独删除 `/legado/cache/`、`/legado/covers/` 或 `/legado/downloads/`；下次使用会重新创建所需目录。删除 `legado.sqlite` 会同时清除书源、书架、进度和下载记录，无法由插件恢复。

## 隐私与版权

运行期 Cookie Jar 按书源隔离且只驻留内存；导入书源自身携带的 Header/Cookie/Authorization 字段会作为书源配置存入本地 `legado.sqlite`。诊断和日志不记录这些值、查询密钥、请求正文或章节正文。缓存、封面和 EPUB 均保存在设备本地。使用者应遵守网站条款与当地版权法律；插件不内置书源合集或固定下载链接，需自行导入书源，不保证第三方网站或高级规则可用。详见 [隐私与版权说明](docs/privacy-and-copyright.md)。

## 开发与验证

Windows 自动测试：

```powershell
powershell -ExecutionPolicy Bypass -File scripts/check-koreader-compat.ps1
powershell -ExecutionPolicy Bypass -File scripts/run-specs.ps1
powershell -ExecutionPolicy Bypass -File scripts/package.ps1 -Version 0.6.5
powershell -ExecutionPolicy Bypass -File scripts/verify-package.ps1 -Archive dist/legado.koplugin-v0.6.5.zip -Version 0.6.5
```

测试依赖放在未跟踪的 `.tools/`，发布物写入未跟踪的 `dist/`。更多说明见 [测试文档](docs/testing.md) 和 [KPW6 手工验收清单](docs/kpw6-checklist.md)。

## 许可证

本项目采用 AGPL-3.0-only。第三方组件许可证与固定版本见 `THIRD_PARTY_NOTICES.md`；vendored `lua-htmlparser` 的 LGPL 文本保留在插件目录中。
