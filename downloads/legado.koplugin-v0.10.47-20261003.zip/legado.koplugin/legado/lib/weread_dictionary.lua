local Text=require('legado.lib.leko_text')
local Dictionary={}
function Dictionary.word(value)
    if type(value)~='string' then return nil end
    value=value:match('^%s*(.-)%s*$')
    value=value:match('^《(.-)》$') or value
    if value=='' or #value>512 or value:find('[%c<>]') then return nil end
    return value
end
function Dictionary.definition(wire)
    if type(wire)~='table' or tonumber(wire.status)~=1 then
        return nil,'词典查询失败，请检查网络或重新扫码登录后重试。'
    end
    local pieces={}
    local function add(value)
        if type(value)=='string' and #value<=64*1024 then
            value=Text.plainText(value)
            if value~='' then pieces[#pieces+1]=value end
        end
    end
    add(wire.baike)
    local encyclopedia=#pieces>0
    if not encyclopedia then
        local results=type(wire.message)=='table' and wire.message.result
        if type(results)=='table' then
            for index=1,math.min(#results,20) do
                if type(results[index])=='table' then add(results[index].mean) end
            end
        end
    end
    if #pieces==0 then return nil,'微信读书词典暂未提供这个词条的背景说明。' end
    local source=encyclopedia and tonumber(wire.source)==1 and '微信读书词典 · 搜狗百科' or '微信读书词典'
    return {text=table.concat(pieces,'\n\n'),source=source}
end
return Dictionary
